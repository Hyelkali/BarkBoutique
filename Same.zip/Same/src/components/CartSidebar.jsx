"use client"
import { X, Trash2, Plus, Minus, ShoppingCart } from "lucide-react"
import { useCart } from "./CartContext"
import { Button } from "./ui/button"
import { useNavigate } from "react-router-dom"

export function CartSidebar() {
  const { isOpen, toggleCart, cart, removeFromCart, updateQuantity, totalPrice } = useCart()
  const navigate = useNavigate()

  const handleCheckout = () => {
    toggleCart() // Close the cart
    navigate("/checkout") // Navigate to checkout
  }

  return (
    <>
      {/* Overlay */}
      {isOpen && <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={toggleCart} />}

      {/* Sidebar */}
      <div
        className={`fixed top-0 right-0 h-full w-full sm:w-96 bg-dark-800 z-50 transform transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex justify-between items-center p-4 border-b border-dark-600">
            <h2 className="text-xl font-bold">Your Cart</h2>
            <button onClick={toggleCart} className="p-1 rounded-full hover:bg-dark-600">
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Cart Items */}
          <div className="flex-grow overflow-y-auto p-4">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-400">
                <ShoppingCart className="w-16 h-16 mb-4" />
                <p>Your cart is empty</p>
              </div>
            ) : (
              <ul className="space-y-4">
                {cart.map((item) => (
                  <li key={item.id} className="flex border-b border-dark-600 pb-4">
                    <div className="w-20 h-20 bg-dark-700 rounded overflow-hidden mr-4 flex-shrink-0">
                      <img
                        src={item.image1 || "/placeholder.svg"}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-medium">{item.name}</h3>
                      <p className="text-gray-400">${item.price.toFixed(2)}</p>
                      {item.selectedSize && <p className="text-xs text-gray-400">Size: {item.selectedSize}</p>}

                      <div className="flex items-center mt-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 rounded-full hover:bg-dark-600"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="mx-2">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 rounded-full hover:bg-dark-600"
                        >
                          <Plus className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="ml-auto p-1 rounded-full hover:bg-dark-600 text-red-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-dark-600">
            <div className="flex justify-between mb-4">
              <span>Total:</span>
              <span className="font-bold">${totalPrice.toFixed(2)}</span>
            </div>
            <Button className="w-full" disabled={cart.length === 0} onClick={handleCheckout}>
              Checkout
            </Button>
          </div>
        </div>
      </div>
    </>
  )
}
