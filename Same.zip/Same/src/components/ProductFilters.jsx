"use client"

import { useState } from "react"
import { Button } from "./ui/button"
import { Sliders, X } from "lucide-react"

export function ProductFilters({ categories, onFilterChange }) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [priceRange, setPriceRange] = useState([0, 300])

  const handleCategoryChange = (category) => {
    setSelectedCategory(category)
    onFilterChange({
      category: category === "all" ? null : category,
      priceRange,
    })
  }

  const handlePriceChange = (e, index) => {
    const newPriceRange = [...priceRange]
    newPriceRange[index] = Number.parseInt(e.target.value)
    setPriceRange(newPriceRange)
    onFilterChange({
      category: selectedCategory === "all" ? null : selectedCategory,
      priceRange: newPriceRange,
    })
  }

  const resetFilters = () => {
    setSelectedCategory("all")
    setPriceRange([0, 300])
    onFilterChange({
      category: null,
      priceRange: [0, 300],
    })
  }

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Filters</h2>
        <Button variant="ghost" size="sm" className="flex items-center gap-2" onClick={() => setIsOpen(!isOpen)}>
          <Sliders className="w-4 h-4" />
          <span className="hidden sm:inline">Filter</span>
        </Button>
      </div>

      <div
        className={`transition-all duration-300 ${isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0 overflow-hidden"}`}
      >
        <div className="bg-dark-800 p-4 rounded-lg mb-4">
          <div className="mb-4">
            <h3 className="text-sm font-medium mb-2">Categories</h3>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant={selectedCategory === "all" ? "default" : "ghost"}
                onClick={() => handleCategoryChange("all")}
              >
                All
              </Button>
              {categories.map((category) => (
                <Button
                  key={category}
                  size="sm"
                  variant={selectedCategory === category ? "default" : "ghost"}
                  onClick={() => handleCategoryChange(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          <div className="mb-4">
            <h3 className="text-sm font-medium mb-2">Price Range</h3>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <input
                  type="range"
                  min="0"
                  max="300"
                  value={priceRange[0]}
                  onChange={(e) => handlePriceChange(e, 0)}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>$0</span>
                  <span>$300</span>
                </div>
              </div>
              <span className="text-sm">
                ${priceRange[0]} - ${priceRange[1]}
              </span>
              <div className="flex-1">
                <input
                  type="range"
                  min="0"
                  max="300"
                  value={priceRange[1]}
                  onChange={(e) => handlePriceChange(e, 1)}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>$0</span>
                  <span>$300</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <Button size="sm" variant="ghost" onClick={resetFilters} className="flex items-center gap-1">
              <X className="w-3 h-3" /> Reset
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
