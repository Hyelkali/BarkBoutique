"use client"

import { useState } from "react"
import { useCart } from "./CartContext"
import { Button } from "./ui/button"
import { ShoppingCart } from "lucide-react"

export function HoodieCard({ id, name, price, image1, image2 }) {
  const [isHovered, setIsHovered] = useState(false)
  const { addToCart } = useCart()

  const handleAddToCart = (e) => {
    e.preventDefault() // Prevent navigation when clicking the button
    e.stopPropagation() // Stop event propagation
    addToCart({ id, name, price, image1, image2 })
  }

  return (
    <div className="bg-dark-800 rounded-lg overflow-hidden h-full transition-transform duration-200 hover:-translate-y-1">
      <div
        className="relative aspect-square"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <img
          src={isHovered ? image2 : image1}
          alt={name}
          className="w-full h-full object-cover transition-opacity duration-300"
        />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-100">{name}</h3>
        <p className="text-gray-400 mb-4">${price.toFixed(2)}</p>
        <Button className="w-full flex items-center justify-center gap-2" variant="outline" onClick={handleAddToCart}>
          <ShoppingCart className="w-4 h-4" /> Add to Cart
        </Button>
      </div>
    </div>
  )
}
