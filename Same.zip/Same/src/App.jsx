import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { CartProvider } from "./components/CartContext"
import Home from "./pages/Home"
import ProductDetail from "./pages/ProductDetail"
import Checkout from "./pages/Checkout"
import { SplashScreen } from "./components/SplashScreen"
import { Logo } from "./components/Logo"
import { CustomCursor } from "./components/CustomCursor"

function App() {
  return (
    <CartProvider>
      <Router>
        <div className="bg-dark-900 text-gray-100 min-h-screen">
          <SplashScreen />
          <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 pointer-events-none">
            <Logo />
          </div>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/product/:id" element={<ProductDetail />} />
            <Route path="/checkout" element={<Checkout />} />
          </Routes>
          <footer className="w-full py-6 px-4 bg-dark-600 text-gray-400">
            <div className="container mx-auto text-center">
              <p>&copy; 2023 Pallets3D. All rights reserved.</p>
            </div>
          </footer>
          <CustomCursor />
        </div>
      </Router>
    </CartProvider>
  )
}

export default App
