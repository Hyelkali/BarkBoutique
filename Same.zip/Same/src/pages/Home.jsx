"use client"

import { useState } from "react"
import { Link } from "react-router-dom"
import { HoodieCard } from "../components/HoodieCard"
import { AutoSliderBanner } from "../components/AutoSliderBanner"
import { CartIcon } from "../components/CartIcon"
import { CartSidebar } from "../components/CartSidebar"
import { ProductFilters } from "../components/ProductFilters"
import products, { getCategories } from "../data/products"

export default function Home() {
  const [filters, setFilters] = useState({
    category: null,
    priceRange: [0, 300],
  })

  const categories = getCategories()

  // Apply filters to products
  const filteredProducts = products.filter((product) => {
    // Filter by category
    if (filters.category && product.category !== filters.category) {
      return false
    }

    // Filter by price range
    if (product.price < filters.priceRange[0] || product.price > filters.priceRange[1]) {
      return false
    }

    return true
  })

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters)
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      {/* Fixed Cart Icon */}
      <div className="fixed top-4 right-4 z-50">
        <CartIcon />
      </div>

      {/* Cart Sidebar */}
      <CartSidebar />

      {/* Full-screen Auto-sliding Banner */}
      <AutoSliderBanner />

      {/* Product Section */}
      <section id="product-section" className="w-full py-12 md:py-24 bg-dark-900">
        <div className="container mx-auto px-4">
          <h2 className="mb-8 text-3xl font-bold text-center text-gray-100">Latest Collection</h2>

          {/* Product Filters */}
          <ProductFilters categories={categories} onFilterChange={handleFilterChange} />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredProducts.map((hoodie) => (
              <Link to={`/product/${hoodie.id}`} key={hoodie.id} className="block">
                <HoodieCard {...hoodie} />
              </Link>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400">No products match your filters.</p>
            </div>
          )}
        </div>
      </section>
    </main>
  )
}
