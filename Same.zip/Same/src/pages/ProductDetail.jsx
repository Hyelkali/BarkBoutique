"use client"

import { useEffect, useState } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { Button } from "../components/ui/button"
import { useCart } from "../components/CartContext"
import { ArrowLeft, Heart, Share2, ShoppingBag } from "lucide-react"
import { getProductById } from "../data/products"

export default function ProductDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { addToCart } = useCart()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [selectedSize, setSelectedSize] = useState("M")
  const [currentImage, setCurrentImage] = useState(0)
  const [isWishlisted, setIsWishlisted] = useState(false)

  useEffect(() => {
    // Simulate loading product data
    setLoading(true)
    const fetchedProduct = getProductById(Number.parseInt(id))

    if (fetchedProduct) {
      setProduct(fetchedProduct)
      // Add additional images for the product detail page
      fetchedProduct.images = [
        fetchedProduct.image1,
        fetchedProduct.image2,
        fetchedProduct.image1, // Duplicate for demo purposes
        fetchedProduct.image2, // Duplicate for demo purposes
      ]
    }

    setLoading(false)

    // Scroll to top when component mounts
    window.scrollTo(0, 0)
  }, [id])

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-pulse">Loading...</div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
          <Button onClick={() => navigate("/")}>Back to Home</Button>
        </div>
      </div>
    )
  }

  const handleAddToCart = () => {
    addToCart({
      ...product,
      selectedSize,
    })
  }

  const toggleWishlist = () => {
    setIsWishlisted(!isWishlisted)
  }

  const sizes = ["XS", "S", "M", "L", "XL", "XXL"]

  return (
    <div className="container mx-auto px-4 py-12">
      <Button variant="ghost" className="mb-6 flex items-center gap-2" onClick={() => navigate("/")}>
        <ArrowLeft className="w-4 h-4" /> Back to Products
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-square bg-dark-800 rounded-lg overflow-hidden">
            <img
              src={product.images[currentImage] || "/placeholder.svg"}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {product.images.map((image, index) => (
              <div
                key={index}
                className={`aspect-square bg-dark-800 rounded-lg overflow-hidden cursor-pointer border-2 ${
                  currentImage === index ? "border-white" : "border-transparent"
                }`}
                onClick={() => setCurrentImage(index)}
              >
                <img
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div>
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          <div className="text-2xl font-semibold mb-4">${product.price.toFixed(2)}</div>

          <div className="mb-6">
            <h2 className="text-sm font-medium mb-2">Description</h2>
            <p className="text-gray-400">
              {product.description ||
                `Premium quality ${product.name.toLowerCase()} made with the finest materials for ultimate comfort and style. Features a relaxed fit with a soft inner lining and durable construction.`}
            </p>
          </div>

          <div className="mb-6">
            <h2 className="text-sm font-medium mb-2">Size</h2>
            <div className="flex flex-wrap gap-2">
              {sizes.map((size) => (
                <Button
                  key={size}
                  variant={selectedSize === size ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedSize(size)}
                >
                  {size}
                </Button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <h2 className="text-sm font-medium mb-2">Features</h2>
            <ul className="list-disc list-inside text-gray-400">
              <li>Premium cotton blend</li>
              <li>Relaxed fit</li>
              <li>Machine washable</li>
              <li>Embroidered logo</li>
            </ul>
          </div>

          <div className="flex gap-4">
            <Button className="flex-1 flex items-center justify-center gap-2" onClick={handleAddToCart}>
              <ShoppingBag className="w-4 h-4" /> Add to Cart
            </Button>
            <Button variant="outline" onClick={toggleWishlist}>
              <Heart className={`w-5 h-5 ${isWishlisted ? "fill-white" : ""}`} />
            </Button>
            <Button variant="outline">
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
