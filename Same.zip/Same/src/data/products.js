// Product data with categories
const products = [
  {
    id: 1,
    name: "Pallets3D Classic Black",
    price: 149.99,
    image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
    image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    category: "Classic",
    description:
      "Our signature classic black hoodie made with premium cotton blend for ultimate comfort. Features a relaxed fit and minimalist design.",
  },
  {
    id: 2,
    name: "Pallets3D Premium Gray",
    price: 154.99,
    image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
    image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    category: "Classic",
    description:
      "Premium gray hoodie with a soft inner lining and durable construction. Perfect for everyday wear with a comfortable fit.",
  },
  {
    id: 3,
    name: "Pallets3D Signature Navy",
    price: 159.99,
    image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
    image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    category: "Signature",
    description:
      "Our signature navy hoodie featuring embroidered logo and premium materials. Designed for style and comfort with a modern fit.",
  },
  {
    id: 4,
    name: "Pallets3D Limited Edition",
    price: 199.99,
    image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
    image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    category: "Limited",
    description:
      "Limited edition hoodie with exclusive design elements and premium quality materials. Each piece is numbered and comes with a certificate of authenticity.",
  },
  {
    id: 5,
    name: "Pallets3D Urban Camo",
    price: 169.99,
    image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
    image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    category: "Urban",
    description:
      "Urban camo pattern hoodie designed for the city explorer. Features a water-resistant outer shell and comfortable inner lining.",
  },
  {
    id: 6,
    name: "Pallets3D Vintage Wash",
    price: 179.99,
    image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
    image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    category: "Vintage",
    description:
      "Vintage wash hoodie with a lived-in feel from day one. Made with our special washing process for a unique, comfortable texture.",
  },
  {
    id: 7,
    name: "Pallets3D Neon Accent",
    price: 189.99,
    image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
    image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    category: "Urban",
    description:
      "Bold hoodie with neon accent details that stand out in any setting. Features reflective elements for visibility at night.",
  },
  {
    id: 8,
    name: "Pallets3D Distressed Black",
    price: 174.99,
    image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
    image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    category: "Vintage",
    description:
      "Distressed black hoodie with a worn-in aesthetic. Each piece features unique distressing patterns for an individual look.",
  },
]

// Get all unique categories
export const getCategories = () => {
  const categories = products.map((product) => product.category)
  return [...new Set(categories)]
}

// Get product by ID
export const getProductById = (id) => {
  return products.find((product) => product.id === id)
}

// Export products
export default products
